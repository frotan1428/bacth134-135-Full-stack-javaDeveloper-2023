package com.tpe.domain.enums;

public enum UserRole {

    ROLE_STUDENT,//0
    ROLE_ADMIN //1


}

package com.tpe.repository;

import com.tpe.domain.Role;
import com.tpe.domain.enums.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository//this is optional
public interface RoleRepository extends JpaRepository<Role,Integer> {

    Optional<Role> findByName(UserRole type);


}

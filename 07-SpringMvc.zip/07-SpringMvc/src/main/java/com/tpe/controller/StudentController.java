package com.tpe.controller;

import com.tpe.domain.Student;
import com.tpe.exception.ResourceNotFoundException;
import com.tpe.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

//@Component
@Controller
@RequestMapping("/students")////http://localhost:8080/SpringMVC/students
////This annotation is used to map HTTP requests to specific methods in a controller
//The @RequestMapping annotation can be applied at both the class and method level in Spring.
//@RestController// this annotation that combine  @Controller and  @responseBody

//class level to define a default mapping for all methods in the class,
// Method  level :specifies the URI path and HTTP method for handling a specific Method.

public class StudentController {

    @Autowired
    private StudentService service;


    @GetMapping("/hi")////http://localhost:8080/SpringMVC/students/hi+get
    //@GetMapping that handles HTTP GET requests with a URI path of "/hi".
    public ModelAndView sayHi(){
        ModelAndView mav=new ModelAndView();
        mav.addObject("message","HI ,");
        mav.addObject("messagebody","I am A students Management System");
        mav.setViewName("hi");//hi.jsp;
        return mav;//model and view
    }

    //1-create Students
    //ModelAttribute: ModelAttribute is used to bind request parameters to a model object.
    //@ModelAttribute :This is done to provide a reference of the Student object to the view
    // so that the view can bind form data to the Student object.

    @GetMapping("/new")////http://localhost:8080/SpringMVC/students/new+get
    public String sentStudentFrom(@ModelAttribute("student") Student student){
        return "studentForm";
    }

    //@PostMapping - This annotation is used to map HTTP POST requests to a specific method in the controller class.
//    @PostMapping("/saveStudent")///http://localhost:8080/SpringMVC/students/saveStudent+post
//    private String CreateStudent(@ModelAttribute() Student student){
//        service.saveStudent(student);
//        return "redirect:/students";//http://localhost:8080/SpringMVC/students
//
//    }
    //    //validation If there are any validation errors, they will be stored in the BindingResult object.
    @PostMapping("/saveStudent")//http://localhost:8080/SpringMVC/students/saveStudent+POST
    public String createStudent(@Valid @ModelAttribute Student student, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            return "studentForm";
        }
        service.saveStudent(student);
        return "redirect:/students";//http://localhost:8080/SpringMVC/students
    }
    //BindingResult: BindingResult is used to capture and report any validation errors that occur during form binding.


    //to get of  students request:http://localhost:8080/SpringMVC/students
    //2-read:all Record
    @GetMapping//http://localhost:8080/SpringMVC/students
    public ModelAndView listAllStudents(){
        List<Student> students=service.getAll();
        ModelAndView mav=new ModelAndView();
        mav.addObject("studentList",students);
        mav.setViewName("students");//students.jsp
        return mav;
    }


    //
    //got StudentRepositoryImpl and complete update method

    //3-update:http://localhost:8080/SpringMVC/students/update?id=4
//    @GetMapping("/update")
//    public ModelAndView showFormForUpdate(@Valid @RequestParam("id") Long id){
//          Student foundStudent=service.getStudentById(id);
//          ModelAndView mav=new ModelAndView();
//          mav.addObject("student",foundStudent);//which binds the Student object to the "student" key in the model.
//          mav.setViewName("studentForm");
//          return mav;
//    }

//    //2nd method for Update
    @GetMapping("/update")
    public String showFormForUpdate(@Valid @RequestParam("id") Long id, Model model){
        Student foundStudent=service.getStudentById(id);
        model.addAttribute("student",foundStudent);
        return "studentForm";
    }
    //@RequestParam - This annotation is used to bind a request parameter to a controller method parameter.



//    //4-delete:http://localhost:8080/SpringMVC/students/delete/1
    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable("id") Long id){
        service.deleteStudent(id);
        return "redirect:/students";
    }
//    //@PathVariable - This annotation is used to extract a path variable from the URL
//    // and pass it as a parameter to the controller method.
//
//    //5-Exception Handling
    @ExceptionHandler(ResourceNotFoundException.class)
    public ModelAndView handleResourceNotFoundException(Exception ex){
        ModelAndView mav=new ModelAndView();
        mav.addObject("message",ex.getMessage());
        mav.setViewName("notFound");
        return mav;
    }
//    // @ExceptionHandler that handles exceptions to type ResourceNotFoundException.
//    //@ExceptionHandler - This annotation is used to handle exceptions thrown by a controller method
//    // and send an appropriate error response to the client.
//
//
//    //restful service:to return all Record :http://localhost:8080/SpringMVC/students/restAll
    @GetMapping("/restAll")
    @ResponseBody////Spring will serialize the return value of the method directly into the response body
    // converter to serialize the list into a JSON or XML response that can be consumed by a client.
    public List<Student> getAllStudents(){
        List<Student> studentList=service.getAll();
        return studentList;
    }
//



}

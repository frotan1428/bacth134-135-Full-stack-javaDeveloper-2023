package com.tpe.domain;

public class Message {
    private String message;
    //getter-settter

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

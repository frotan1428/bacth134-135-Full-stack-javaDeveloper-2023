package com.tpe.repository;

import com.tpe.domain.Message;

public interface Repository {
    void save(Message message);
}

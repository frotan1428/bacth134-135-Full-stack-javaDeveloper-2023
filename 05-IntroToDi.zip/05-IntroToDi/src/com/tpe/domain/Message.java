package com.tpe.domain;

public class Message {
    private String message;

    //getter and setter

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

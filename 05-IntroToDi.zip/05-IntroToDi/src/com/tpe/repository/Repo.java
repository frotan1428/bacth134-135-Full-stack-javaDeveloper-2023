package com.tpe.repository;

import com.tpe.domain.Message;

public interface Repo {
    void saveMessage(Message message);
}

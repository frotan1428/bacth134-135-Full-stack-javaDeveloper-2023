package enums.intro;
//The enum data type is (also known  as enumerated data type )
public enum DaysOfWeek {
    //defining enum within class
    SUNDAY,SATURDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY;
    // the semicolon (;) at hte end of enum constant are optional
}

package generics.genericinterface;

public class GenericInterfaceImpl02 implements GenericInterface<Integer>{
    @Override
    public void setValue(Integer s) {

    }
    @Override
    public Integer getValue() {
        return null;
    }
}

package generics.genericinterface.example;

public class Customer {
    private String name;
}

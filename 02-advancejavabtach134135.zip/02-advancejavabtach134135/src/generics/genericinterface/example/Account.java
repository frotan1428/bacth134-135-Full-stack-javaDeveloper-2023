package generics.genericinterface.example;

public class Account {
    private Long account_no;
}
